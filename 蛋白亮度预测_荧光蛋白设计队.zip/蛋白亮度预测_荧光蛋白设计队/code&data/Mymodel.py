import torch
import torch.nn as nn
import torch.nn.functional as F

class RDBlock(nn.Module):
    #'''A dense layer with residual connection'''#它是一个带有残差连接的全连接层（dense layer）。
    def __init__(self, dim ):
        super(RDBlock, self).__init__()
        self.dense = nn.Linear(dim, dim)
    #创建一个全连接层（线性变换），输入维度和输出维度都为 dim。
    #命名为 dense，暗示它执行“密集”层操作。
    def forward(self, x):
        x0 = x
        x = F.leaky_relu( self.dense(x) )
        #self.dense(x) 将输入通过全连接层进行线性变换。
        #然后使用 F.leaky_relu() 进行激活，leaky_relu 是一种带泄露斜率的 ReLU 函数，能避免 ReLU 的“死神经元”问题。
        x = x0 + x
        #将经过激活函数处理后的结果 x 与原始输入 x0 相加。
        #这种“跳跃连接”（skip connection）是残差网络的关键设计，可以有效缓解深层网络的训练问题，促进梯度直接流动，从而让模型更容易训练和更深。
        return x



class MultiAttModel(nn.Module):
    def __init__(self, dim, window, n_head, n_RD):
        # dim：输入数据的特征维数（例如，蛋白质序列经过嵌入后的维度）。
        # window：卷积操作的窗口参数，用来确定卷积核大小。
        # n_head：表示多头注意力的头数，这里每个“头”都会独立计算注意力权重。
        # n_RD：残差密集块（ResidualBlock）的数量，用于进一步融合特征。
        super(MultiAttModel, self).__init__()
        self.n_RD = n_RD
        self.n_head = n_head
        #将传入的参数 n_RD 和 n_head 保存在实例属性中，后续在前向传播中会用到。
        self.cnn_v = nn.Conv1d(dim, dim, kernel_size=2*window+1, padding=window)
        # 输入通道和输出通道均为dim：表示该卷积层在特征维度上不改变通道数。
        # kernel_size为2 * window + 1：这样可以使卷积的感受野覆盖序列中以当前位置为中心的左右window个位置。
        # padding = window：保证经过卷积后，输出的长度与输入长度一致（“samepadding”）。
        self.W_cnns = nn.ModuleList([ nn.Conv1d(dim, dim, kernel_size=2*window+1, padding=window) for _ in range(n_head)])
        #创建了一个 ModuleList，其中包含 n_head 个一维卷积层，每个卷积层结构与 cnn_v 类似。
        self.RDs = nn.ModuleList([RDBlock(2*n_head*dim) for _ in range(n_RD)])
        #输入给 RDBlock 的特征维数为 2*n_head*dim，这是因为后续会将多个头的池化结果拼接，拼接后特征维度翻倍
        self.output = nn.Linear(2*n_head*dim, 1)
        #将特征维度为 2*n_head*dim 的拼接特征映射到一个标量输出。
        
    def forward(self, emb):
        values = self.cnn_v(emb)
        for i in range( self.n_head ):
            weights = F.softmax(self.W_cnns[i](emb), dim=-1)
            #F.softmax 对最后一个维度进行归一化，获得注意力分布（权重），确保每个位置的权重之和为 1。
            x_sum = torch.sum(values * weights, dim=-1) # Sum pooling
            #对于每个头，将 values 与对应的注意力 weights 相乘后沿着序列长度（最后一个维度）求和，得到一个经过注意力加权后的汇总特征。
            x_max,_ = torch.max(values * weights, dim=-1) # Max pooling
            #同样对 values 与 weights 的乘积沿序列维度取最大值，得到另一种汇总方式——最大池化。
            #x_max, _ 表示我们只需要最大值，而不关心对应的索引位置。下划线 _ 常用来表示不需要的变量。

            if i == 0:
                cat_xsum = x_sum
                cat_xmax = x_max
            else:
                cat_xsum = torch.cat([cat_xsum, x_sum],dim=1)
                cat_xmax = torch.cat([cat_xmax, x_max],dim=1)
            #第一次循环（i==0）时，直接将第一个头的池化结果赋值给 cat_xsum 和 cat_xmax。
            # 之后的每个头，通过 torch.cat 将对应的 x_sum 与 x_max 沿着通道维度（dim=1）进行拼接。
            #torch.cat是用来连接张量的函数，它将多个张量沿着指定的维度拼接起来。
                
        cat_f = torch.cat([ cat_xsum, cat_xmax ], dim=1) # Concat features for regression
        #求和池化和最大池化的结果在通道维度上拼接，得到一个综合的特征向量 cat_f，其维度为 2*n_head*dim。
        for j in range(self.n_RD):
            cat_f = self.RDs[j](cat_f)
        # 初始时，cat_f是由前面的注意力和池化操作拼接而来的一个特征张量。
        # 当循环第一次执行时，cat_f经过self.RDs[0]的处理后获得新的输出。
        # 循环接着进入第二次、第三次···直至n_RD次，每一次都将上一次的输出作为输入，进一步对特征进行加工。
        return self.output(cat_f)

            




        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
        
    
