import math
import pickle
import numpy as np
import pandas as pd
import argparse
import torch
import torch.optim as optim
from torch import nn
import torch.nn.functional as F
from function import *
from Mymodel import MultiAttModel
import os
import warnings
import random
import esm
from torch.utils.data import Dataset, DataLoader # 预测时可能需要
'''
Run the training process. ESM-2
'''



'''
辅助函数占位符 (如果不在 function.py 中，需要实现)
'''
def get_rmse(y_true, y_pred):
    return np.sqrt(np.mean((np.array(y_true) - np.array(y_pred))**2))

def get_r2(y_true, y_pred):
    y_true = np.array(y_true)
    y_pred = np.array(y_pred)
    ss_res = np.sum((y_true - y_pred)**2)
    ss_tot = np.sum((y_true - np.mean(y_true))**2)
    if ss_tot == 0: # 防止除以零
        return 1.0 if ss_res == 0 else 0.0
    return 1 - (ss_res / ss_tot)

def get_mae(y_true, y_pred):
    return np.mean(np.abs(np.array(y_true) - np.array(y_pred)))

def rescale_targets(targets, max_val, min_val):
    # Min-Max 缩放到 [0, 1]
    targets = np.array(targets)
    if max_val == min_val:
        print("警告: 缩放范围的最大值和最小值相等。返回全零数组。")
        return np.zeros_like(targets, dtype=float)
    return (targets - min_val) / (max_val - min_val)

def inverse_rescale_targets(scaled_targets, max_val, min_val):
    # 从 [0, 1] 反向缩放
    scaled_targets = np.array(scaled_targets)
    if max_val == min_val:
        # 如果原始范围为零，则所有反向缩放值都应等于该单一值
        return np.full_like(scaled_targets, min_val, dtype=float)
    return scaled_targets * (max_val - min_val) + min_val

# --- 数据集类 (用于预测) ---
class PredictionSequenceDataset(Dataset):
    def __init__(self, ids, sequences):
        self.ids = ids
        self.sequences = sequences

    def __len__(self):
        return len(self.ids)

    def __getitem__(self, idx):
        # 返回ID和序列，供后续批处理和嵌入
        return self.ids[idx], self.sequences[idx]


'''
设置随机种子以保证可复现性
'''
def set_random_seeds(seed):
    np.random.seed(seed)
    random.seed(seed)
    torch.manual_seed(seed)
    if torch.cuda.is_available():
        torch.cuda.manual_seed_all(seed)
    # 确保cudnn确定性，可能会牺牲一些性能
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark = False
    print(f"随机种子设置为: {seed}")


'''
修改后的训练和验证函数
- 不再处理 test_pack (无标签)
- 在 dev_pack 上进行验证
- 返回性能字典和最佳模型状态
'''
def train_eval(model, esm2_model, esm2_batch_converter,
               train_pack, dev_pack, device, lr, batch_size, lr_decay,
               decay_interval, num_epochs, min_val=None, max_val=None):

    criterion = F.mse_loss # 均方误差损失
    optimizer = optim.Adam(model.parameters(), lr=lr, weight_decay=0, amsgrad=True)
    scheduler = optim.lr_scheduler.StepLR(optimizer, step_size=decay_interval, gamma=lr_decay)

    train_ids, train_seqs, train_targets_processed = train_pack
    dev_ids, dev_seqs, dev_targets_processed = dev_pack

    # 性能记录字典
    train_result = {'epoch':[], 'rmse_train':[],'r2_train':[],'mae_train':[],
                    'rmse_dev':[],'r2_dev':[],'mae_dev':[]}

    best_dev_metric = float('inf') # 假设我们关心的是RMSE或MAE，越小越好
    best_model_state = None

    # --- 梯度累积设置 ---
    # 使用较小的min_size进行批处理，累积梯度后再更新
    min_size = 4 # 每次送入 ESM 的批次大小，可以根据显存调整
    if batch_size < min_size:
        print(f"警告: batch_size ({batch_size}) 小于 min_size ({min_size})。将使用 batch_size 作为实际处理单元。")
        accumulation_steps = 1
        actual_processing_size = batch_size
    elif batch_size % min_size != 0:
         print(f"警告: batch_size ({batch_size}) 不能被 min_size ({min_size}) 整除。梯度累积可能不完全精确。")
         accumulation_steps = max(1, batch_size // min_size)
         actual_processing_size = min_size
    else:
         accumulation_steps = batch_size // min_size
         actual_processing_size = min_size
    print(f"训练设置: 总批次大小={batch_size}, ESM处理单元大小={actual_processing_size}, 梯度累积步数={accumulation_steps}")
    # ---

    num_train_samples = len(train_ids)
    train_indices = np.arange(num_train_samples)

    for epoch in range(num_epochs):
        # --- 训练阶段 ---
        model.train()
        esm2_model.eval() # ESM模型通常在微调时也设为eval模式，只更新下游模型参数
        np.random.shuffle(train_indices) # 每个epoch打乱训练数据

        epoch_train_preds_processed, epoch_train_targets_processed = [], []
        optimizer.zero_grad() # 每个epoch开始时或梯度累积循环外清零

        for i in range(0, num_train_samples, actual_processing_size):
            batch_indices = train_indices[i : i + actual_processing_size]
            if len(batch_indices) == 0: continue

            batch_ids = train_ids[batch_indices]
            batch_seqs = train_seqs[batch_indices]
            batch_y_processed = train_targets_processed[batch_indices]

            # 准备 ESM 输入
            input_data = [(str(batch_ids[j]), batch_seqs[j]) for j in range(len(batch_ids))] # ID需要是字符串
            _, _, batch_tokens = esm2_batch_converter(input_data)
            batch_tokens = batch_tokens.to(device=device, non_blocking=True)

            # 获取 ESM 嵌入 (不计算梯度)
            with torch.no_grad():
                esm_output = esm2_model(batch_tokens, repr_layers=[6], return_contacts=False)
            emb = esm_output["representations"][6] # (batch, seqlen, features)
            # 注意：MultiAttModel期望的维度可能是 (batch, features, seqlen)
            emb = emb.permute(0, 2, 1) # 转换为 (batch, features, seqlen)
            emb = emb.to(device) # 确保在正确设备上

            # 目标值转换为 Tensor
            target_values = torch.tensor(batch_y_processed, dtype=torch.float32).view(-1, 1) # (batch, 1)
            target_values = target_values.to(device)

            # 模型前向传播
            pred = model(emb) # (batch, 1)
            loss = criterion(pred, target_values)

            # 缩放损失以进行梯度累积
            loss = loss / accumulation_steps
            loss.backward() # 计算梯度

            epoch_train_preds_processed.extend(pred.cpu().detach().numpy().flatten())
            epoch_train_targets_processed.extend(target_values.cpu().numpy().flatten())

            # 梯度累积步骤
            if (i // actual_processing_size + 1) % accumulation_steps == 0:
                # 执行优化器步骤并清零梯度
                optimizer.step()
                optimizer.zero_grad()

        # 处理最后一个不满 `accumulation_steps` 的梯度 (如果存在)
        # 注意：上面的循环结束后，如果 `(num_train_samples / actual_processing_size)` 不是 `accumulation_steps` 的整数倍，
        # 可能还有未更新的梯度。通常在循环外再执行一次 `optimizer.step()` 和 `optimizer.zero_grad()`，
        # 但这可能导致最后一个“小批次”的梯度被放大。更严谨的做法是在循环内处理好。
        # 另一种做法是如果最后一个批次不满，则跳过 optimizer.step() 直到下一次循环。
        # 为了简单起见，上述代码在每次累积满步数时更新。

        # --- 验证阶段 ---
        model.eval() # 设置模型为评估模式
        epoch_dev_preds_processed, epoch_dev_targets_processed = [], []
        dev_loss_total = 0.0
        num_dev_batches = math.ceil(len(dev_ids) / batch_size) # 验证时使用完整 batch_size

        with torch.no_grad(): # 验证时不需要计算梯度
            for j in range(num_dev_batches):
                start_idx = j * batch_size
                end_idx = min((j + 1) * batch_size, len(dev_ids))
                if start_idx == end_idx: continue

                batch_dev_ids = dev_ids[start_idx:end_idx]
                batch_dev_seqs = dev_seqs[start_idx:end_idx]
                batch_dev_y_processed = dev_targets_processed[start_idx:end_idx]

                # 准备 ESM 输入
                dev_input_data = [(str(batch_dev_ids[k]), batch_dev_seqs[k]) for k in range(len(batch_dev_ids))]
                _, _, dev_batch_tokens = esm2_batch_converter(dev_input_data)
                dev_batch_tokens = dev_batch_tokens.to(device=device, non_blocking=True)

                # 获取 ESM 嵌入
                dev_esm_output = esm2_model(dev_batch_tokens, repr_layers=[6], return_contacts=False)
                dev_emb = dev_esm_output["representations"][6]
                dev_emb = dev_emb.permute(0, 2, 1) # (batch, features, seqlen)
                dev_emb = dev_emb.to(device)

                # 目标值
                dev_target_values = torch.tensor(batch_dev_y_processed, dtype=torch.float32).view(-1, 1)
                dev_target_values = dev_target_values.to(device)

                # 模型预测
                dev_pred = model(dev_emb)
                loss = criterion(dev_pred, dev_target_values)
                dev_loss_total += loss.item() * len(batch_dev_ids) # 累加批次损失 (乘以批大小)

                epoch_dev_preds_processed.extend(dev_pred.cpu().numpy().flatten())
                epoch_dev_targets_processed.extend(dev_target_values.cpu().numpy().flatten())

        # --- 计算和记录指标 ---
        # 需要将处理后的 (可能缩放的) 预测和目标转换回原始尺度来计算有意义的指标
        if min_val is not None and max_val is not None: # 如果进行了缩放
            epoch_train_preds_orig = inverse_rescale_targets(epoch_train_preds_processed, max_val, min_val)
            epoch_train_targets_orig = inverse_rescale_targets(epoch_train_targets_processed, max_val, min_val)
            epoch_dev_preds_orig = inverse_rescale_targets(epoch_dev_preds_processed, max_val, min_val)
            epoch_dev_targets_orig = inverse_rescale_targets(epoch_dev_targets_processed, max_val, min_val)
        else: # 没有缩放
            epoch_train_preds_orig = np.array(epoch_train_preds_processed)
            epoch_train_targets_orig = np.array(epoch_train_targets_processed)
            epoch_dev_preds_orig = np.array(epoch_dev_preds_processed)
            epoch_dev_targets_orig = np.array(epoch_dev_targets_processed)

        # 计算原始尺度上的指标
        rmse_train = get_rmse(epoch_train_targets_orig, epoch_train_preds_orig)
        r2_train = get_r2(epoch_train_targets_orig, epoch_train_preds_orig)
        mae_train = get_mae(epoch_train_targets_orig, epoch_train_preds_orig)

        avg_dev_loss = dev_loss_total / len(dev_ids) if len(dev_ids) > 0 else 0
        rmse_dev = get_rmse(epoch_dev_targets_orig, epoch_dev_preds_orig)
        r2_dev = get_r2(epoch_dev_targets_orig, epoch_dev_preds_orig)
        mae_dev = get_mae(epoch_dev_targets_orig, epoch_dev_preds_orig)

        train_result['epoch'].append(epoch + 1)
        train_result['rmse_train'].append(rmse_train)
        train_result['r2_train'].append(r2_train)
        train_result['mae_train'].append(mae_train)
        train_result['rmse_dev'].append(rmse_dev)
        train_result['r2_dev'].append(r2_dev)
        train_result['mae_dev'].append(mae_dev)

        print(f"Epoch: {epoch+1}/{num_epochs} | "
              f"Train RMSE: {rmse_train:.4f}, R2: {r2_train:.4f}, MAE: {mae_train:.4f} | "
              f"Dev RMSE: {rmse_dev:.4f}, R2: {r2_dev:.4f}, MAE: {mae_dev:.4f} | "
              f"Dev Loss (processed): {avg_dev_loss:.4f}") # 打印处理后尺度的 Dev Loss

        # 更新学习率
        scheduler.step()

        # 保存最佳模型 (基于验证集指标，例如 RMSE)
        current_dev_metric = rmse_dev # 或者 mae_dev
        if current_dev_metric < best_dev_metric:
            best_dev_metric = current_dev_metric
            best_model_state = model.state_dict()
            print(f"  ** New best model saved (Dev RMSE: {best_dev_metric:.4f}) at epoch {epoch+1} **")

    return train_result, best_model_state


'''
预测函数 (用于无标签的测试集)
'''
def predict(model, esm2_model, esm2_batch_converter,
            test_pack, device, batch_size, min_val=None, max_val=None):

    model.eval() # 设置模型为评估模式
    esm2_model.eval()

    test_ids, test_seqs = test_pack # 测试集只有 ID 和序列

    dataset = PredictionSequenceDataset(test_ids, test_seqs)
    # 注意: DataLoader 可能需要 collate_fn 来处理不同长度序列的批处理 (ESM转换器通常会处理)
    dataloader = DataLoader(dataset, batch_size=batch_size, shuffle=False)

    all_preds_processed = []
    all_original_ids = []

    with torch.no_grad():
        for batch_ids, batch_seqs_tuple in dataloader:
            # batch_seqs_tuple 是一个元组，需要转换为列表或直接使用
            batch_seqs_list = list(batch_seqs_tuple)
            if not batch_seqs_list: continue

            # 准备 ESM 输入 (ID 需要是字符串)
            input_data = [(str(batch_ids[j]), batch_seqs_list[j]) for j in range(len(batch_ids))]

            try:
                _, _, batch_tokens = esm2_batch_converter(input_data)
            except Exception as e:
                print(f"错误发生在 ESM batch conversion: {e}")
                print(f"问题数据 (部分): IDs={batch_ids[:5]}, Seqs={batch_seqs_list[:5]}")
                # 可以选择跳过这个批次或采取其他错误处理
                continue # 跳过这个批次

            batch_tokens = batch_tokens.to(device=device, non_blocking=True)

            # 获取 ESM 嵌入
            esm_output = esm2_model(batch_tokens, repr_layers=[6], return_contacts=False)
            emb = esm_output["representations"][6]
            emb = emb.permute(0, 2, 1) # (batch, features, seqlen)
            emb = emb.to(device)

            # 模型预测
            preds = model(emb) # (batch, 1)
            all_preds_processed.extend(preds.cpu().numpy().flatten())
            all_original_ids.extend(list(batch_ids)) # 直接使用dataloader返回的原始ID

    # 如果训练时缩放了目标，则反向缩放预测结果
    if min_val is not None and max_val is not None:
        print(f"对预测结果进行反向缩放，范围: [{min_val:.4f}, {max_val:.4f}]")
        final_preds = inverse_rescale_targets(all_preds_processed, max_val, min_val)
    else:
        print("未进行反向缩放 (训练时目标未缩放)")
        final_preds = np.array(all_preds_processed)

    # 创建结果 DataFrame
    results_df = pd.DataFrame({
        'id': all_original_ids, # 使用从 dataloader 中收集的 ID
        'prediction': final_preds
    })
    return results_df


'''
数据分割函数 (保持不变)
'''
def split_data( data, ratio=0.1):
    # data 是一个列表，包含 [ids, sequences, targets]
    idx = np.arange(len( data[0]))
    np.random.shuffle(idx)
    num_split = int(len(data[0]) * ratio)
    idx_dev, idx_train = idx[:num_split], idx[num_split:] # 分割出验证集 (dev)
    # 创建训练集 pack
    data_train = [ data[di][idx_train] for di in range(len(data))]
    # 创建验证集 pack
    data_dev = [ data[di][idx_dev] for di in range(len(data))]
    print(f"数据分割: {len(data_train[0])} 训练样本, {len(data_dev[0])} 验证样本")
    return data_train, data_dev


# ================= 主程序入口 =================
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='使用 ESM2 嵌入训练模型预测 light 值')
    #parser.add_argument('--train_path', required=True, help="训练数据 CSV 文件路径 (包含 ID, 序列, light 值)")
    #parser.add_argument('--test_path', required=True, help="测试数据 CSV 文件路径 (包含 ID, 序列, 无 light 值)")

    # --- 数据列参数 ---
    parser.add_argument('--id_col', default='id', help="CSV 文件中包含 ID 的列名")
    parser.add_argument('--sequence_col', default='sequence', help="CSV 文件中包含氨基酸序列的列名")
    parser.add_argument('--target_col', default='light', help="训练 CSV 文件中包含目标值 (light) 的列名")

    # --- 训练超参数 ---
    parser.add_argument('--lr', default=0.0005, type=float, help="学习率")
    parser.add_argument('--batch', default=32, type=int, help="批次大小 (会影响梯度累积)")
    parser.add_argument('--lr_decay', default=0.5, type=float, help="学习率衰减因子")
    parser.add_argument('--decay_interval', default=10, type=int, help="学习率衰减间隔 (epochs)")
    parser.add_argument('--num_epoch', default=30, type=int, help="训练轮数")

    # --- 控制参数 ---
    parser.add_argument('--no_scale_target', action='store_true', help="如果指定，则不对目标值 'light' 进行 Min-Max 缩放")
    parser.add_argument('--seed', default=0, type=int, help="随机种子")

    # --- 输出路径参数 ---
    parser.add_argument('--output_perf_dir', default='./data/performances/', help="保存训练性能指标文件的目录")
    parser.add_argument('--output_preds_dir', default='./data/predictions/', help="保存测试集预测结果文件的目录")

    args = parser.parse_args([])

    # --- 设置随机种子 ---
    set_random_seeds(args.seed)

    #---路径---
    train_path = r"D:\PythonC\Pythonpro\pythonProject1\.venv\play\GFPall.csv"
    test_path = r"D:\PythonC\Pythonpro\pythonProject1\.venv\play\GFPtest.csv"

    # --- 解析参数 ---
    id_col, seq_col, target_col = args.id_col, args.sequence_col, args.target_col
    lr, batch_size, lr_decay, decay_interval, num_epochs = \
        args.lr, args.batch, args.lr_decay, args.decay_interval, args.num_epoch
    scale_target = not args.no_scale_target # 如果指定了 --no_scale_target，则 scale_target 为 False

    task = target_col # 任务名现在就是目标列名
    print(f'任务: 预测 {task}')
    print(f"读取训练数据: {train_path}")
    print(f"读取测试数据: {test_path}")
    print(f"使用列名 -> ID: '{id_col}', Sequence: '{seq_col}', Target: '{target_col}'")

    # --- 加载数据 ---
    try:
        # 加载训练数据 (ID, 序列, 目标值)
        train_data = pd.read_csv(train_path, usecols=[id_col, seq_col, target_col])
        # 加载测试数据 (仅 ID, 序列)
        test_data = pd.read_csv(test_path, usecols=[id_col, seq_col])
        print(f"成功加载 {len(train_data)} 条训练样本和 {len(test_data)} 条测试样本。")
    except FileNotFoundError as e:
        print(f"错误: 文件未找到 - {e}")
        exit(1)
    except ValueError as e:
        print(f"错误: 读取 CSV 时列名配置错误 - {e}")
        print(f"请确认 '{id_col}', '{seq_col}', '{target_col}' 存在于 {train_path}")
        print(f"并且 '{id_col}', '{seq_col}' 存在于 {test_path}")
        exit(1)
    except Exception as e:
        print(f"加载数据时发生未知错误: {e}")
        exit(1)

    # --- 目标值处理与缩放 ---
    min_val, max_val = None, None
    train_targets_raw = train_data[target_col].values

    if scale_target:
        print("启用目标值 Min-Max 缩放 ([0, 1])")
        min_val = np.min(train_targets_raw)
        max_val = np.max(train_targets_raw)
        print(f"  从训练数据检测到的缩放范围: [{min_val:.4f}, {max_val:.4f}]")
        if min_val == max_val:
            print("警告: 目标值范围为零，缩放可能无效或导致全零输出。")
        train_targets_processed = rescale_targets(train_targets_raw, max_val, min_val)
    else:
        print("目标值缩放已禁用，使用原始值。")
        train_targets_processed = train_targets_raw # 直接使用原始值

    # --- 准备数据包 ---
    train_ids = np.array(train_data[id_col])
    train_sequences = np.array(train_data[seq_col])
    test_ids = np.array(test_data[id_col])
    test_sequences = np.array(test_data[seq_col])

    # 训练数据完整包 (用于分割)
    train_pack_full = [train_ids, train_sequences, train_targets_processed]
    # 测试数据包 (用于最终预测)
    test_pack = [test_ids, test_sequences]

    # --- 分割训练集为训练/验证集 ---
    train_pack, dev_pack = split_data(train_pack_full, ratio=0.1) # 10% 作为验证集

    # --- 设置设备 ---
    device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
    print(f'使用设备: {device}')

    # --- 加载 ESM-2 模型 (一次性) ---
    print("正在加载 ESM-2 模型 (esm2_t6_8M_UR50D)...")
    try:
        esm2_model, alphabet = esm.pretrained.esm2_t6_8M_UR50D()
        esm2_model = esm2_model.to(device)
        esm2_model.eval() # 通常保持评估模式
        esm2_batch_converter = alphabet.get_batch_converter()
        print("ESM-2 模型加载完成。")
    except Exception as e:
        print(f"加载 ESM-2 模型失败: {e}")
        exit(1)

    # --- 忽略特定警告 ---
    warnings.filterwarnings("ignore", message="Setting attributes on ParameterList is not supported.")

    # --- 模型参数 ---
    emb_dim = 320  # esm2_t6_8M_UR50D 输出维度
    n_head = 4     # MultiAttModel 参数
    n_RD = 4       # MultiAttModel 参数

    # --- 创建输出目录 ---
    os.makedirs(args.output_perf_dir, exist_ok=True)
    os.makedirs(args.output_preds_dir, exist_ok=True)

    # --- 按窗口大小训练和预测 ---
    for win_size in [3, 5, 7]:
        print(f"\n{'='*20} 开始训练: 窗口大小 = {win_size} {'='*20}")

        # --- 初始化下游模型 ---
        model = MultiAttModel(emb_dim, win_size, n_head, n_RD)
        model.to(device)
        print(f"MultiAttModel (win_size={win_size}) 初始化完成，在 {device}上。")

        # --- 训练和验证 ---
        train_performance, best_model_state = train_eval(
            model, esm2_model, esm2_batch_converter,
            train_pack, dev_pack, device, lr, batch_size, lr_decay,
            decay_interval, num_epochs,
            min_val=min_val if scale_target else None, # 传递缩放参数
            max_val=max_val if scale_target else None
        )

        # --- 保存性能指标 ---
        perf_df = pd.DataFrame(train_performance)
        perf_output_path = os.path.join(args.output_perf_dir, f'{task}_window{win_size}_performance.csv')
        perf_df.to_csv(perf_output_path, index=False)
        print(f"训练/验证性能指标已保存到: {perf_output_path}")

        # --- 使用最佳模型进行预测 ---
        if best_model_state:
            print(f"\n--- 使用最佳模型 (win_size={win_size}) 在测试集上生成预测 ---")
            # 加载最佳模型状态
            model.load_state_dict(best_model_state)

            # 调用预测函数
            predictions_df = predict(
                model, esm2_model, esm2_batch_converter,
                test_pack, device, batch_size,
                min_val=min_val if scale_target else None, # 传递缩放参数
                max_val=max_val if scale_target else None
            )

            # --- 保存预测结果 ---
            preds_output_path = os.path.join(args.output_preds_dir, f'{task}_window{win_size}_predictions.csv')
            predictions_df.to_csv(preds_output_path, index=False)
            print(f"预测结果已保存到: {preds_output_path}")
            print(f"预测文件包含 {len(predictions_df)} 条记录。")

        else:
            print(f"警告: 未能从训练中获取最佳模型状态 (win_size={win_size})，跳过预测步骤。")

        print(f"\n{'='*20} 窗口大小 = {win_size} 处理完成 {'='*20}")

    print('\n所有训练和预测流程已完成。')