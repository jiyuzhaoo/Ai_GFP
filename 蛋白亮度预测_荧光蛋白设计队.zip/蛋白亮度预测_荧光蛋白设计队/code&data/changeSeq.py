def mutate_sequence_multi(seq, mutations):
    if isinstance(mutations, list):
        mut_dict = {pos: aa for pos, aa in mutations}
    else:
        mut_dict = mutations

    seq_len = len(seq)
    seq_list = list(seq)

    for pos, new_aa in mut_dict.items():
        if not (1 <= pos <= seq_len):
            raise ValueError(f"Position {pos} out of range (1–{seq_len})")
        if len(new_aa) != 1:
            raise ValueError(f"Replacement residue '{new_aa}' at position {pos} is invalid")
        seq_list[pos - 1] = new_aa

    return "".join(seq_list)

# 示例用法：
original_seq = "MSKGEELFTGVVPILVELDGDVNGHKFSVSGEGEGDATYGKLTLKFICTTGKLPVPWPTLVTTLSYGVQCFSRYPDHMKQHDFFKSAMPEGYVQERTIFFKDDGNYKTRAEVKFEGDTLVNRIELKGIDFKEDGNILGHKLEYNYNSHNVYIMADKQKNGIKVNFKIRHNIEDGSVQLADHYQQNTPIGDGPVLLPDNHYLSTQSALSKDPNEKRDHMVLLEFVTAAGITHGMDELYK"
# 多个突变：第1位->V，第5位->G，第10位->W
mutations = {202:'Y',158:'K',171:"V",105:'S',163:'A'}
new_seq = mutate_sequence_multi(original_seq, mutations)
print(new_seq)  # 输出：VKTIGALSYW FCLVFA

