import os
import numpy as np
import sys
import pickle
from sklearn.metrics import r2_score, mean_absolute_error
import torch
import math
from math import sqrt
import requests
from urllib import request
import html
from collections import Counter


def split_table( table, ratio ):
    idx=list(table.index)
    np.random.shuffle(idx)
    num_split = int( len(idx) * ratio)
    idx_test, idx_train = idx[:num_split], idx[num_split:]
    train_table = (table.iloc[idx_train]).reset_index().drop(['index'],axis=1)
    test_table = (table.iloc[idx_test]).reset_index().drop(['index'],axis=1)
    return train_table,test_table


'''
Three evaluation methods.
'''
def get_rmse(x,y):#均方根误差（RMSE）
    rmse = sqrt(((x - y)**2).mean(axis=0))
    return round(rmse, 6)
#(x - y)**2：先计算预测与真实值的误差平方。
# .mean(axis=0)：计算所有样本误差平方的平均值。
# sqrt(...)：对平均值取平方根，得到 RMSE。
def get_r2(x,y):#定义函数 get_r2 用于计算 R²，即判定系数，反映模型解释方差的比例。
    return round( r2_score(x,y), 6)
#使用 sklearn.metrics 中的 r2_score 函数计算 R²。
#结果四舍五入到 6 位小数后返回。
def get_mae(x,y):#平均绝对误差（MAE）
    return  round( mean_absolute_error(x,y), 6 )




def run( cmd ):
    os.system( cmd )
    return None

def load_pickle(filename):
    temp = None
    with open(filename,'rb') as f:
        temp = pickle.load(f)
    return temp
        
def dump_pickle(file, filename):
    with open(filename, 'wb') as f:
        pickle.dump( file , f)

        
def rescale_targets(target_values, x_max, x_min):
    return [ (x-x_min)/(x_max-x_min) for x in target_values]


# AAC（氨基酸组成）描述了序列中单个氨基酸的比例。
# DPC（二肽组成）描述了序列中两两相邻氨基酸的比例。
# 结合这两种特征，可以更全面地捕获蛋白质序列的局部和全局信息。
# 这些特征在机器学习模型中是非常重要的输入，能帮助预测任务（例如预测酶的最优温度）。
def get_aac(seq):#用来计算蛋白质序列的氨基酸组成 (Amino Acid Composition, AAC) 的函数。
    # 这个函数的意义是统计给定蛋白质序列中每种氨基酸的比例。
    AA = 'ACDEFGHIKLMNPQRSTVWY'
    output = {}
    for aa in AA:
        output['AAC_'+aa] = seq.count(aa)/len(seq)
    return output
#计算蛋白质序列中每种氨基酸的比例。       意义： 提取全局特征，反映序列中氨基酸的总体分布。

def get_dpc(seq):
    '''
    dipeptide composition (DPC)
    '''
    output = {}
    AA = 'ACDEFGHIKLMNPQRSTVWY'
    DPs = [aa1 + aa2 for aa1 in AA for aa2 in AA]
    for dp in DPs:
        output['DPC_'+ dp] = seq.count(dp)/(len(seq)-1)
    return output
#计算蛋白质序列中所有二肽（相邻两个氨基酸的组合）的比例。     意义： 提取局部特征，捕获序列中的短距离依赖关系。

def get_aacdpc(seq):#这是一个结合了氨基酸组成（AAC）和二肽组成（DPC）的特征提取函数，同时处理了模糊氨基酸的情况。
    if 'X' in seq:
        most_aa = Counter(seq).most_common()[0][0]
        if most_aa == 'X':
            most_aa = Counter(seq).most_common()[1][0]
        seq = seq.replace('X',most_aa)
    results = get_aac(seq)
    results.update( get_dpc(seq) )
    return results
#处理模糊氨基酸（X）：
# 在实际数据中，蛋白质序列可能包含未知氨基酸（用 X 表示）。
# 直接使用这样的序列会导致特征提取不准确，因此需要对 X 进行合理替代。
# 代码通过统计序列中最常见的氨基酸，将 X 替换为最常见的氨基酸，以最大程度减少对特征计算的干扰。