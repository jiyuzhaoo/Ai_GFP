import csv
import re # 虽然在这个特定例子中用不上正则，但处理更复杂的fasta头时可能会用到

def fasta_to_csv(fasta_filepath, csv_filepath):
    """
    将 FASTA 文件转换为 CSV 文件。

    CSV 文件包含三列：
    - id: 从 0 开始的序列标识符
    - light: 从 FASTA 标题行提取的第二个由 '-' 分隔的值
    - sequence: 完整的氨基酸/核苷酸序列

    Args:
        fasta_filepath (str): 输入的 FASTA 文件路径。
        csv_filepath (str): 输出的 CSV 文件路径。
    """
    records = []
    current_id_counter = 0
    current_sequence = []
    current_light_value = None

    try:
        with open(fasta_filepath, 'r') as infile:
            for line in infile:
                line = line.strip()
                if not line:  # 跳过空行
                    continue

                if line.startswith('>'):
                    # 1. 如果我们已经有了一个序列，处理并保存上一个记录
                    if current_sequence:
                        full_sequence = "".join(current_sequence)
                        if current_light_value is not None:
                             records.append({
                                 'id': current_id_counter,
                                 'light': current_light_value,
                                 'sequence': full_sequence
                             })
                             current_id_counter += 1 # 准备下一个ID
                        else:
                            print(f"警告：在上一个标题 '{last_header_line}' 中未找到有效的 'light' 值，跳过记录。")

                    # 2. 开始处理新的记录
                    header_line = line[1:] # 去掉 '>'
                    last_header_line = header_line # 存储以供可能的错误消息使用
                    current_sequence = [] # 重置序列列表
                    current_light_value = None # 重置 light 值

                    # 3. 从标题行提取 light 值
                    parts = header_line.split('-')
                    if len(parts) > 1:
                        try:
                            # 假设 light 值是第二个部分
                            current_light_value = float(parts[1])
                        except ValueError:
                            print(f"警告：无法将 '{parts[1]}' 从标题 '{header_line}' 转换为浮点数。")
                            current_light_value = None # 标记为无效
                        except IndexError:
                             print(f"警告：标题 '{header_line}' 格式不符合预期（缺少 '-' 分隔符或部分）。")
                             current_light_value = None # 标记为无效
                    else:
                         print(f"警告：标题 '{header_line}' 格式不符合预期（缺少 '-' 分隔符）。")

                else:
                    # 如果不是标题行，并且我们已经遇到了一个有效的标题，则添加到当前序列
                    if current_light_value is not None or current_sequence is not None: # 确保我们在一个记录内部
                      current_sequence.append(line)

            # 处理文件末尾的最后一个记录
            if current_sequence and current_light_value is not None:
                full_sequence = "".join(current_sequence)
                records.append({
                    'id': current_id_counter,
                    'light': current_light_value,
                    'sequence': full_sequence
                })
            elif current_sequence and current_light_value is None:
                 print(f"警告：在文件末尾的上一个标题 '{last_header_line}' 中未找到有效的 'light' 值，跳过最后一个记录。")


    except FileNotFoundError:
        print(f"错误：找不到输入的 FASTA 文件 '{fasta_filepath}'")
        return
    except Exception as e:
        print(f"读取 FASTA 文件时发生错误：{e}")
        return

    # 写入 CSV 文件
    if not records:
        print("没有有效的记录可写入 CSV 文件。")
        return

    try:
        with open(csv_filepath, 'w', newline='', encoding='utf-8') as outfile:
            # 定义列名
            fieldnames = ['id', 'light', 'sequence']
            writer = csv.DictWriter(outfile, fieldnames=fieldnames)

            # 写入表头
            writer.writeheader()
            # 写入数据行
            writer.writerows(records)

        print(f"成功将 '{fasta_filepath}' 转换为 '{csv_filepath}'")

    except IOError as e:
        print(f"写入 CSV 文件时发生错误 '{csv_filepath}': {e}")
    except Exception as e:
        print(f"写入 CSV 时发生未知错误: {e}")
input_fasta_file = r'D:\PythonC\Pythonpro\pythonProject1\.venv\play\GFP_sequences(1).fasta'  # <--- 修改这里：你的 FASTA 文件名
output_csv_file = 'GFPall.csv'       # <--- 修改这里：你想要生成的 CSV 文件名
fasta_to_csv(input_fasta_file, output_csv_file)
